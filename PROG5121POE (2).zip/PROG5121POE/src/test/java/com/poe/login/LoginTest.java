package com.poe.login;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit tests built from the "Test Data and expected system responses" table
 * supplied in the PROG5121 POE Part 1 brief.
 */
public class LoginTest {

    private Login login;

    @BeforeEach
    public void setUp() {
        login = new Login();
    }

    // ---------- checkUserName ----------

    @Test
    public void testUserName_CorrectlyFormatted() {
        // Username contains an underscore and is no more than five characters long.
        assertTrue(login.checkUserName("kyl_1"));
    }

    @Test
    public void testUserName_IncorrectlyFormatted() {
        // Username does not contain an underscore and is more than five characters long.
        assertFalse(login.checkUserName("kyle!!!!!!"));
    }

    // ---------- checkPasswordComplexity ----------

    @Test
    public void testPassword_MeetsComplexityRequirements() {
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test
    public void testPassword_DoesNotMeetComplexityRequirements() {
        assertFalse(login.checkPasswordComplexity("password"));
    }

    // ---------- checkCellPhoneNumber ----------

    @Test
    public void testCellPhoneNumber_CorrectlyFormatted() {
        assertTrue(login.checkCellPhoneNumber("+27838968976"));
    }

    @Test
    public void testCellPhoneNumber_IncorrectlyFormatted() {
        assertFalse(login.checkCellPhoneNumber("08966553"));
    }

    // ---------- registerUser (assertEquals on returned message) ----------

    @Test
    public void testRegisterUser_UsernameIncorrectlyFormatted() {
        String result = login.registerUser("kyle!!!!!!", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        assertEquals("Username is not correctly formatted; please ensure that your username "
                + "contains an underscore and is no more than five characters in length.", result);
    }

    @Test
    public void testRegisterUser_PasswordIncorrectlyFormatted() {
        String result = login.registerUser("kyl_1", "password", "+27838968976", "Kyle", "Smith");
        assertEquals("Password is not correctly formatted; please ensure that the password "
                + "contains at least eight characters, a capital letter, a number, and a "
                + "special character.", result);
    }

    @Test
    public void testRegisterUser_CellPhoneIncorrectlyFormatted() {
        String result = login.registerUser("kyl_1", "Ch&&sec@ke99!", "08966553", "Kyle", "Smith");
        assertEquals("Cell phone number incorrectly formatted or does not contain international "
                + "code; please correct the number and try again.", result);
    }

    @Test
    public void testRegisterUser_Successful() {
        String result = login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        assertEquals("User successfully registered.", result);
    }

    // ---------- loginUser (assertTrue/assertFalse) ----------

    @Test
    public void testLoginUser_Successful() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testLoginUser_Failed() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        assertFalse(login.loginUser("kyl_1", "wrongPassword1!"));
    }

    // ---------- returnLoginStatus ----------

    @Test
    public void testReturnLoginStatus_Successful() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        login.loginUser("kyl_1", "Ch&&sec@ke99!");
        String result = login.returnLoginStatus(true);
        assertEquals("Welcome Kyle, Smith it is great to see you again.", result);
    }

    @Test
    public void testReturnLoginStatus_Failed() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        String result = login.returnLoginStatus(false);
        assertEquals("Username or password incorrect, please try again.", result);
    }
}
