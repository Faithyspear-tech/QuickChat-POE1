package com.poe.login;

import java.util.regex.Pattern;

/**
 * Contains all the registration / login validation and processing logic
 * required for Part 1 of the PROG5121 POE.
 *
 * Regex resources consulted while building the validation patterns:
 * - Username / Password: https://www.baeldung.com/java-regex-password-validation
 * - South African cell phone number format: https://www.regular-expressions.info/
 */
public class Login {

    // Username: must contain an underscore and be no more than five characters long.
    private static final Pattern USERNAME_PATTERN = Pattern.compile("^(?=.{1,5}$)(?=.*_).*$");

    // Password: at least 8 characters, at least one capital letter, one number
    // and one special character.
    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^(?=.*[A-Z])(?=.*[0-9])(?=.*[^a-zA-Z0-9]).{8,}$");

    // South African cell phone number: must start with the international
    // country code (+27) followed by the subscriber number.
    private static final Pattern CELLPHONE_PATTERN = Pattern.compile("^\\+27[0-9]{9}$");

    private User registeredUser;

    /**
     * Checks that the username contains an underscore and is no more than
     * five characters long.
     */
    public boolean checkUserName(String username) {
        if (username == null) {
            return false;
        }
        return USERNAME_PATTERN.matcher(username).matches();
    }

    /**
     * Checks that the password is at least eight characters long and
     * contains a capital letter, a number and a special character.
     */
    public boolean checkPasswordComplexity(String password) {
        if (password == null) {
            return false;
        }
        return PASSWORD_PATTERN.matcher(password).matches();
    }

    /**
     * Checks that the cell phone number contains the international country
     * code (+27) followed by the number, which is no more than ten
     * characters long.
     */
    public boolean checkCellPhoneNumber(String cellPhoneNumber) {
        if (cellPhoneNumber == null) {
            return false;
        }
        return CELLPHONE_PATTERN.matcher(cellPhoneNumber).matches();
    }

    /**
     * Registers a user, validating the username, password and cell phone
     * number, and returns the appropriate message to display to the user.
     */
    public String registerUser(String username, String password, String cellPhoneNumber,
                                String firstName, String lastName) {

        if (!checkUserName(username)) {
            return "Username is not correctly formatted; please ensure that your username "
                    + "contains an underscore and is no more than five characters in length.";
        }

        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the password "
                    + "contains at least eight characters, a capital letter, a number, and a "
                    + "special character.";
        }

        if (!checkCellPhoneNumber(cellPhoneNumber)) {
            return "Cell phone number incorrectly formatted or does not contain international "
                    + "code; please correct the number and try again.";
        }

        registeredUser = new User(username, password, cellPhoneNumber, firstName, lastName);
        return "User successfully registered.";
    }

    /**
     * Verifies that the entered username and password match the details
     * captured when the user registered.
     */
    public boolean loginUser(String username, String password) {
        if (registeredUser == null || username == null || password == null) {
            return false;
        }
        return registeredUser.getUsername().equals(username)
                && registeredUser.getPassword().equals(password);
    }

    /**
     * Returns the appropriate login status message.
     */
    public String returnLoginStatus(boolean loginSuccessful) {
        if (loginSuccessful && registeredUser != null) {
            return "Welcome " + registeredUser.getFirstName() + ", " + registeredUser.getLastName()
                    + " it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }

    public User getRegisteredUser() {
        return registeredUser;
    }
}
