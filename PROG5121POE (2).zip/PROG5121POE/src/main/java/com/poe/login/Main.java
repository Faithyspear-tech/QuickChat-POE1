package com.poe.login;

import java.util.Scanner;

/**
 * Simple console driven demo of the registration and login feature.
 * Run this class in NetBeans (Run > Run File, or mvn exec:java) to try it
 * out interactively.
 */
public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        System.out.println("=== PROG5121 POE - Part 1: Registration and Login ===");

        // ----- Registration -----
        String username;
        String password;
        String cellPhoneNumber;
        String firstName;
        String lastName;
        String registerMessage;

        do {
            System.out.print("Enter a username (must contain an underscore and be <= 5 characters): ");
            username = scanner.nextLine();

            System.out.print("Enter a password (min 8 chars, 1 capital, 1 number, 1 special char): ");
            password = scanner.nextLine();

            System.out.print("Enter your South African cell phone number (e.g. +27838968976): ");
            cellPhoneNumber = scanner.nextLine();

            System.out.print("Enter your first name: ");
            firstName = scanner.nextLine();

            System.out.print("Enter your last name: ");
            lastName = scanner.nextLine();

            registerMessage = login.registerUser(username, password, cellPhoneNumber, firstName, lastName);
            System.out.println(registerMessage);
            System.out.println();

        } while (!registerMessage.equals("User successfully registered."));

        // ----- Login -----
        System.out.println("\n--- Please log in ---");
        System.out.print("Enter your username: ");
        String loginUsername = scanner.nextLine();
        System.out.print("Enter your password: ");
        String loginPassword = scanner.nextLine();

        boolean loginSuccessful = login.loginUser(loginUsername, loginPassword);
        String statusMessage = login.returnLoginStatus(loginSuccessful);
        System.out.println(statusMessage);

        scanner.close();
    }
}
